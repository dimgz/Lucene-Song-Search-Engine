package com.example.demo;

import java.io.File;
import java.io.FileFilter;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.io.*;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.*;

import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.DocValuesType;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexableFieldType;
import org.apache.lucene.search.Sort;
import org.apache.lucene.index.IndexOptions;

import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.BytesRef;
import org.apache.lucene.util.Version;

public class Indexing {
	
	
	private static Document getDocument(String field1, String field2, String field3) throws IOException, IllegalStateException
	{
		String artist = field1;
		String title = field2;
		String lyrics = field3;
		Document documents = new Document();
		
		
	    /*																				//USED FOR GROUPING
		FieldType artistFieldType = new FieldType();
		artistFieldType.setStored(true);
		artistFieldType.setIndexOptions(IndexOptions.DOCS_AND_FREQS_AND_POSITIONS);
		//artistFieldType.setDocValuesType(DocValuesType.SORTED_SET);
		artistFieldType.setTokenized(true);
		
		FieldType titleFieldType = new FieldType();
		titleFieldType.setStored(true);
		titleFieldType.setIndexOptions(IndexOptions.DOCS_AND_FREQS_AND_POSITIONS);
		//titleFieldType.setDocValuesType(DocValuesType.SORTED_SET);
		titleFieldType.setTokenized(true);
		
		FieldType lyricsFieldType = new FieldType();
		lyricsFieldType.setStored(true);
		lyricsFieldType.setIndexOptions(IndexOptions.DOCS_AND_FREQS_AND_POSITIONS);
		//lyricsFieldType.setDocValuesType(DocValuesType.SORTED_SET);
		titleFieldType.setTokenized(true);
		
		
		Field ArtistField = new Field(LuceneConstants.ARTIST, artist, artistFieldType);
		Field TitleField = new Field(LuceneConstants.TITLE, title, titleFieldType);
		Field LyricsField = new Field(LuceneConstants.LYRICS, lyrics, lyricsFieldType);
		
		documents.add(ArtistField);
		documents.add(TitleField);
		documents.add(LyricsField);
		*/
		
	    //Create Fields
	    Field ArtistField = new TextField(LuceneConstants.ARTIST,artist,Field.Store.YES);
		Field TitleField = new TextField(LuceneConstants.TITLE,title,Field.Store.YES);
		Field LyricsField = new TextField(LuceneConstants.LYRICS,lyrics,Field.Store.YES);
		
		//Add fields to document
		documents.add(ArtistField);
		documents.add(TitleField);
		documents.add(LyricsField);
		
		
		return documents;
	}
	
	public static void createIndexer(String filepath) throws IOException
	{
		
		String[] f;
		String f_artist = "";
		String f_title = "";
		String f_lyrics = "";
		String IndexDir = "testindex";		//index
		
		int num = 0;
		
		Analyzer analyzer = new StandardAnalyzer();
		
		//create indexWriter 
		Directory directory = FSDirectory.open(Paths.get(IndexDir));
		IndexWriterConfig config = new IndexWriterConfig(analyzer);
		IndexWriter iwriter = new IndexWriter(directory, config);

		//read the txt file
		
		BufferedReader read;
		Charset charset = StandardCharsets.UTF_8;
		Path find_path = Paths.get(filepath);
		List<String> lines = Files.readAllLines(find_path,charset);
		
		
		try {
			read = new BufferedReader(new FileReader(filepath));
			//String line = read.readLine();
			
			for (String line : lines) {
				if (line.length() > 0)
				{
					//assign the fields
					f=line.split(",,");
					f_artist = f[0].trim();
					f_title = f[1].trim();
					f_lyrics = f[2].trim();
					
					Document doc = getDocument(f_artist,f_title,f_lyrics);
					iwriter.addDocument(doc);									//Add document to the indexWriter
					num++;
					
					
				}
				else
				{
					break;
				}
			}
			read.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		int numberDocs = iwriter.numRamDocs();
		iwriter.commit();
		iwriter.close();
		System.out.println("number of documents created " + numberDocs);
		
	}
	

}
//Dimitrios Gazos AM 4035