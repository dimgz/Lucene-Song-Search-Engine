package com.example.demo;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.border.BevelBorder;
import javax.swing.table.DefaultTableModel;

import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.search.highlight.InvalidTokenOffsetsException;
import org.jdesktop.swingx.autocomplete.AutoCompleteDecorator;

import javax.swing.ListSelectionModel;
import javax.swing.JButton;
import javax.swing.JSplitPane;
import javax.swing.JScrollPane;
import java.awt.Dialog.ModalExclusionType;
import java.awt.Window.Type;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.LineBorder;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JTabbedPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JToolBar;
import javax.swing.JMenuBar;
import javax.swing.SwingConstants;

public class GUI_Panel extends JFrame {

	private JPanel contentPane;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JTextField textField;
	private JTable table;
	private JButton btnNewButton_Prev;
	private JButton btnNewButton_Next;
	
	private String user_mode = "A";				//Default mode is Artist
	private int num_r = 0;						//used like a pointer
	private String[][] Search_array;
	private ArrayList<String> History = new ArrayList<>(); 
	
	public GUI_Panel() {
		setResizable(false);
		
		
		
		setModalExclusionType(ModalExclusionType.APPLICATION_EXCLUDE);
		setTitle("Lucene Search");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 550);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JButton btnNewButton_History = new JButton("History");
		btnNewButton_History.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GUI_History hist = new GUI_History(History);			//open History window
				hist.setVisible(true);
			}
		});
		menuBar.add(btnNewButton_History);
		
		JButton btnNewButton_Help = new JButton("Help");
		btnNewButton_Help.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GUI_Help helpf = new GUI_Help();						//open Help window
				helpf.setVisible(true);
			}
		});
		menuBar.add(btnNewButton_Help);
		
		contentPane = new JPanel();
		

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(134, 205, 405, 23);
		contentPane.add(textField);
		textField.setColumns(10);
		AutoCompleteDecorator.decorate(textField,History,false);   //auto complete from History
		
		JLabel lblNewLabel_1 = new JLabel("Search for:");
		lblNewLabel_1.setBounds(49, 208, 89, 20);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("Search");
		btnNewButton.setBounds(549, 205, 89, 23);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String user_input = textField.getText();		//user input
				History.add(user_input);
				if (user_input.equals(""))
				{
					JOptionPane.showMessageDialog(null, "Field is empty","ERROR",JOptionPane.ERROR_MESSAGE);
				}
				else
				{
					Searching Searcher = new Searching();		
					
					try {
						
						Search_array = Searcher.Search(user_mode,user_input);		//return the array from Searching
						num_r = 0;													//first 10 //starts from 0
						runTable(Search_array,num_r);								//display table format
						btnNewButton_Next.setEnabled(true);
						btnNewButton_Prev.setEnabled(false);
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (ParseException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (InvalidTokenOffsetsException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				
			}
		});
		contentPane.add(btnNewButton);
		
		btnNewButton_Prev = new JButton("Prev");
		btnNewButton_Prev.setBounds(49, 442, 89, 23);
		btnNewButton_Prev.setEnabled(false);
		btnNewButton_Prev.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnNewButton_Next.setEnabled(true);
				num_r -= 10;											
				if (num_r <= 0)
					btnNewButton_Prev.setEnabled(false);
				runTable(Search_array,num_r);				//run the previous 10 
				
			}
		});
		contentPane.add(btnNewButton_Prev);


		btnNewButton_Next = new JButton("Next");
		btnNewButton_Next.setBounds(549, 442, 89, 23);
		btnNewButton_Next.setEnabled(false);
		btnNewButton_Next.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnNewButton_Prev.setEnabled(true);
				num_r += 10;
				if (num_r+10 >= Search_array.length)
					btnNewButton_Next.setEnabled(false);
				
				runTable(Search_array,num_r);				//run the next 10 
			}
		});
		contentPane.add(btnNewButton_Next);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(49, 245, 589, 186);
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (e.getClickCount() == 2)
				{
					JTable target = (JTable)e.getSource();
		            int t_row = target.getSelectedRow(); // select a row
		            int t_column = target.getSelectedColumn(); // select a column
		            GUI_song_info info_gui = new GUI_song_info((String)table.getValueAt(t_row,0),(String)table.getValueAt(t_row,1),(String)table.getValueAt(t_row,2));
					info_gui.setVisible(true);
				}
				
			}
		});
		
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Artist", "Title", "Lyrics"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		scrollPane.setViewportView(table);
		
		JPanel panel = new JPanel();
		panel.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		panel.setBounds(287, 46, 109, 109);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("MODE");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel.setBounds(36, 11, 36, 14);
		panel.add(lblNewLabel);
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("Artist");
		rdbtnNewRadioButton.setBounds(19, 32, 71, 23);
		panel.add(rdbtnNewRadioButton);
		rdbtnNewRadioButton.setSelected(true);
		rdbtnNewRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				user_mode = "A";										//set MODE
			}
		});
		buttonGroup.add(rdbtnNewRadioButton);
		
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("Title");
		rdbtnNewRadioButton_1.setBounds(19, 57, 71, 23);
		panel.add(rdbtnNewRadioButton_1);
		rdbtnNewRadioButton_1.setVerticalAlignment(SwingConstants.TOP);
		rdbtnNewRadioButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				user_mode = "T";
			}
		});
		buttonGroup.add(rdbtnNewRadioButton_1);
		
		JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Lyrics");
		rdbtnNewRadioButton_2.setBounds(19, 82, 71, 23);
		panel.add(rdbtnNewRadioButton_2);
		rdbtnNewRadioButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				user_mode = "L";
			}
		});
		buttonGroup.add(rdbtnNewRadioButton_2);
	}
	
	public void runTable(String[][] tab, int num_rows)
	{
		String[][] tab_temp = tab;
		DefaultTableModel model = (DefaultTableModel) table.getModel();
		model.setRowCount(0);
		String [] row = new String[3];
																
		for (int i=num_rows; i <tab_temp.length; i++)			//if num_rows is 10 it shows 10-20 rows
		{														//if num_rows is 20 20-30 rows for array etc.. 
			
			row[0] = tab_temp[i][0];
			row[1] = tab_temp[i][1];
			row[2] = tab_temp[i][2];
		    model.addRow(row);
		}
		
	}
}
//Dimitrios Gazos AM 4035