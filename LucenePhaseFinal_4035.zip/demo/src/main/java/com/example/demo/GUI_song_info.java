package com.example.demo;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextPane;
import java.awt.Font;
import java.awt.FlowLayout;
import javax.swing.JScrollPane;

public class GUI_song_info extends JFrame {

	private JPanel contentPane;

	
	/**
	 * Create the frame.
	 */
	public GUI_song_info(String f1, String f2, String f3) {
		setResizable(false);
		
		//remove <html> tag
		f1 = f1.replaceAll("<html>", "");
		f1 = f1.replaceAll("</html>", "");
		
		f2 = f2.replaceAll("<html>", "");
		f2 = f2.replaceAll("</html>", "");
		
		f3 = f3.replaceAll("<html>", "");
		f3 = f3.replaceAll("</html>", "");
		
		f3 = f3.replaceAll("  ", "<br>");
		System.out.println(f3);
		
		setTitle("Song Information");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 600, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 0, 584, 461);
		contentPane.add(scrollPane);
		
		JTextPane txtpnHello = new JTextPane();
		txtpnHello.setEditable(false);
		txtpnHello.setContentType("text/html");
		txtpnHello.setText("ARTIST: " + f1 + "<br>" + "TITLE: " + f2 + "<br><br> " + "LYRICS: <br>" + f3);
		scrollPane.setViewportView(txtpnHello);
	}
}
//Dimitrios Gazos AM 4035