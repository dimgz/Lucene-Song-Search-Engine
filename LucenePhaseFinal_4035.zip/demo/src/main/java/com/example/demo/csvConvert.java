package com.example.demo;

import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.opencsv.CSVWriter;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Arrays;

public class csvConvert {

	public csvConvert(String filepath) throws Exception 
	{
		FileWriter myWriter = new FileWriter("converted.txt");
		String csv_file = filepath;
		List<String[]> r;
		try (CSVReader reader = new CSVReader(new FileReader(csv_file)))
		{
			r = reader.readAll();
		}
		
		for (String[] arrays : r) {
			for (String cell : arrays)
			{
				cell = cell.replaceAll("\\n", "");
				myWriter.write(cell);
				myWriter.write(",,");
			}
			myWriter.write("\n");
			
		}
		
		myWriter.close();
        
	}
}
//Dimitrios Gazos AM 4035