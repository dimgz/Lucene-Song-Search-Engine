package com.example.demo;

import java.io.File;
import java.io.FileFilter;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.Arrays;
import java.io.*;
import java.util.*;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;


import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.*;

import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexableFieldType;
import org.apache.lucene.index.Term;
import org.apache.lucene.index.IndexOptions;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.search.FuzzyQuery;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;

import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.Sort;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.TermQuery;

import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.BytesRef;
import org.apache.lucene.util.Version;

import org.apache.lucene.search.grouping.*;
import org.apache.lucene.search.grouping.GroupingSearch.*;
import org.apache.lucene.search.highlight.*;


public class Searching {
	 
	
	public static String[][] Search(String user_input_mode, String text) throws IOException, ParseException, InvalidTokenOffsetsException
	{
		int mark = 0;             				//used to place the frag in the correct field position                     
		String fuzz = "~"; 						//trigger fuzzy query
		
		String user_text = text.toLowerCase();
		user_text = user_text.concat(fuzz);
		
		String user_mode = user_input_mode.toLowerCase();
		String mode = "";
		if (user_mode.equals("a")){
			mode = LuceneConstants.ARTIST;
			mark = 0;
		}
		else if (user_mode.equals("t")){
			mode = LuceneConstants.TITLE;
			mark = 1;
		}
			
		else if (user_mode.equals("l")) {
			mode = LuceneConstants.LYRICS;
			mark = 2;
		}
		else
			System.out.println("Error");
			
		
		Analyzer analyzer = new StandardAnalyzer();
		
		//Create IndexSearcher
		Directory indexDirectory = FSDirectory.open(Paths.get("testindex"));
		
		DirectoryReader ireader = DirectoryReader.open(indexDirectory);
		
		IndexSearcher isearcher = new IndexSearcher(ireader);
		
		//Fuzzy Parser
		QueryParser queryParser = new QueryParser(mode,analyzer); //"fieldname"
		//queryParser.setFuzzyMinSim(3f);					
		queryParser.setFuzzyPrefixLength(2);
		
		Query query = queryParser.parse(user_text);
		
		//collect hits
		TopDocs results = isearcher.search(query, ireader.maxDoc(), Sort.RELEVANCE);		
		ScoreDoc[] hits = results.scoreDocs;
		
		
		//place in array shades
		String[][] shades = new String[hits.length][3];
		for (int i = 0; i < hits.length; i++)
		{
			Document hitDoc = isearcher.doc(hits[i].doc);
			//System.out.print("Artist name: " + hitDoc.get(LuceneConstants.ARTIST) + "|");
			shades[i][0] = hitDoc.get(LuceneConstants.ARTIST);
			//System.out.print("Title name: " + hitDoc.get(LuceneConstants.TITLE) + "|");
			shades[i][1] = hitDoc.get(LuceneConstants.TITLE);
			//System.out.println("Song lyrics: " + hitDoc.get(LuceneConstants.LYRICS));
			shades[i][2] = hitDoc.get(LuceneConstants.LYRICS);
			
			
		}
		
		
		
		//HTML Highlighter 
		SimpleHTMLFormatter htmlFormatter = new SimpleHTMLFormatter();
		Highlighter highlighter = new Highlighter(htmlFormatter, new QueryScorer(query));
		highlighter.setTextFragmenter(new SimpleFragmenter(1000000));
		
		for (int y = 0; y < hits.length; y++)
		{
			
			int id = hits[y].doc;
			Document doc = isearcher.doc(id);
			String text1 = doc.get(mode);
			TokenStream tokenStream = TokenSources.getAnyTokenStream(isearcher.getIndexReader(), id, mode, analyzer);
			TextFragment[] frag = highlighter.getBestTextFragments(tokenStream, text1, false, hits.length);
			
			for (int j = 0; j < frag.length; j++) {
			       if ((frag[j] != null) && (frag[j].getScore() > 0)) {
			         shades[y][mark] = "<html>" + (frag[j].toString()) +  "</html>";		//add frag to shades array
			        
			         
			         
			       }
			     }
		}
		
		
		//System.out.println(hits.length);
		ireader.close();
		indexDirectory.close();
		
		
		return shades;
	}

}

//Dimitrios Gazos AM 4035


////GROUPING ATTEMPTS//////

//GroupingSearch groupingSearch = new GroupingSearch(mode);

//groupingSearch.setGroupSort(Sort.RELEVANCE);
		
//TopGroups<BytesRef> result = groupingSearch.search(isearcher, query,0,100);

/*
for (GroupDocs<BytesRef> group : result.groups) {
    System.out.println("Group " + group.groupValue.utf8ToString() + " (" + group.totalHits + " hits)");
    for (ScoreDoc scoreDoc : group.scoreDocs) {
        Document doc = isearcher.doc(scoreDoc.doc);
        System.out.print("Artist name: " + doc.get(LuceneConstants.ARTIST) + "|");
        System.out.print("Title name: " + doc.get(LuceneConstants.TITLE) + "|");
        System.out.println("Song lyrics: " + doc.get(LuceneConstants.LYRICS));
    }
}
*/

/*

//GroupingSearch groupingSearch = new GroupingSearch(LuceneConstants.ARTIST);
//groupingSearch.setGroupSort(Sort.RELEVANCE);
//groupingSearch.setFillSortFields(true);
//int totalGroupCount = result.totalGroupCount;
*/

/*
//TermQuery query_test = new TermQuery(new Term(mode,user_text));
//TopGroups<BytesRef> result = groupingSearch.search(isearcher, query_test,1,100);
*/

