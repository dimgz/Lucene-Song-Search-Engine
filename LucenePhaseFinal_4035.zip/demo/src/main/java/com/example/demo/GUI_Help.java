package com.example.demo;

import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextArea;
import javax.swing.JTextPane;

public class GUI_Help extends JFrame {

	private JPanel contentPane;

	public GUI_Help() {
		setResizable(false);
		setTitle("Help");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 350);
		contentPane = new JPanel();

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("About Lucene Search");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel.setBounds(10, 11, 160, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("MODE:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
		lblNewLabel_1.setBounds(10, 35, 46, 14);
		contentPane.add(lblNewLabel_1);
		
		JTextArea txtrForExampleIf = new JTextArea();
		txtrForExampleIf.setBackground(new Color(240, 240, 240));
		txtrForExampleIf.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtrForExampleIf.setEditable(false);
		txtrForExampleIf.setText("Select the field that you want to search. \r\nFor example if you choose \"Artist\", \r\nthe keywords you enter search for the artist. ");
		txtrForExampleIf.setBounds(66, 33, 245, 46);
		contentPane.add(txtrForExampleIf);
		
		JLabel lblNewLabel_2 = new JLabel("Search for:");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
		lblNewLabel_2.setBounds(10, 91, 80, 14);
		contentPane.add(lblNewLabel_2);
		
		JTextArea txtrEnterTheKeywords = new JTextArea();
		txtrEnterTheKeywords.setBackground(new Color(240, 240, 240));
		txtrEnterTheKeywords.setText("Enter the keywords that you want to search for in the \r\ndatabase.");
		txtrEnterTheKeywords.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtrEnterTheKeywords.setBounds(100, 89, 324, 34);
		contentPane.add(txtrEnterTheKeywords);
		
		JLabel lblNewLabel_3 = new JLabel("PREV-NEXT:");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
		lblNewLabel_3.setBounds(10, 127, 80, 14);
		contentPane.add(lblNewLabel_3);
		
		JTextArea txtrTheResultsAre = new JTextArea();
		txtrTheResultsAre.setBackground(new Color(240, 240, 240));
		txtrTheResultsAre.setText("The results are displayed ten by ten.\r\nThese buttons are used to change between the pages. ");
		txtrTheResultsAre.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtrTheResultsAre.setBounds(100, 125, 331, 34);
		contentPane.add(txtrTheResultsAre);
		
		JLabel lblNewLabel_img = new JLabel("");
		lblNewLabel_img.setIcon(new ImageIcon("img\\lucene_logo.png"));
		lblNewLabel_img.setBounds(10, 192, 351, 74);
		contentPane.add(lblNewLabel_img);
		
		JTextArea txtrThisProgramWas = new JTextArea();
		txtrThisProgramWas.setBackground(new Color(240, 240, 240));
		txtrThisProgramWas.setFont(new Font("Tahoma", Font.PLAIN, 11));
		txtrThisProgramWas.setText("This Program was created for the University of Ioannina.\r\nCreator: Gazos Dimitrios AM: 4035");
		txtrThisProgramWas.setBounds(10, 266, 278, 34);
		contentPane.add(txtrThisProgramWas);
		
		JLabel lblNewLabel_4 = new JLabel("Powered by:");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblNewLabel_4.setBounds(10, 167, 80, 14);
		contentPane.add(lblNewLabel_4);
	}
}
//Dimitrios Gazos AM 4035