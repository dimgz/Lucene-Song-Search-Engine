package com.example.demo;

import java.io. * ;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import org.apache.commons.io.FileUtils;


public class Main{
	
	
	public static void main( String[] args ) throws Exception
    {
		
		FileUtils.deleteDirectory(new File("testindex"));			//delete previous temp file 
		
		
		System.out.println( "Hello Lucene!" );
		String Path = "corpus\\spotify_millsongdata_1000.csv";
		
		csvConvert readCSV = new csvConvert(Path);
		
		String txtFile = "converted.txt";
		Indexing Indexer = new Indexing();
        Indexer.createIndexer(txtFile);
		
        
		GUI_Panel myGUI = new GUI_Panel();
		myGUI.setVisible(true);
		
		System.out.println("Goodbye!");
		
    }


}

//Dimitrios Gazos AM 4035