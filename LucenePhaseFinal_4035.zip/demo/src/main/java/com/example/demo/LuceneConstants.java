package com.example.demo;

public class LuceneConstants 
{
	
	public static final String ARTIST = "artist";
	public static final String LYRICS = "lyrics";
	public static final String TITLE = "title";
	

}
//Dimitrios Gazos AM 4035